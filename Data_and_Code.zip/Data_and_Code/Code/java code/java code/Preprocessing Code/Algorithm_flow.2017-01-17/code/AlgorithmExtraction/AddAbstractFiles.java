package AlgorithmExtraction;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.stream.IntStream;

import org.apache.commons.io.FileUtils;

import com.opencsv.CSVReader;

import Util.Directory;
import Util.Util;

public class AddAbstractFiles {
	public static double k1 = 2.0; 
	
	public static void main(String args []) {

		//int iteration=1;

		Vector<String> TaggedTextFiles = Directory.listAllFiles("citation paper/Paper_text_synopsis_merged", ".txt", 1);

		
		//String file=null;
		BufferedWriter bw=null;
		BufferedReader br=null;
		String fnew=null;
		String writefile=null;
		try {
			
			System.out.println("In Try");
			CSVReader reader = new CSVReader(new FileReader("./Citation_Text_Paper_unique.csv"));
			String [] nextLine;
			while ((nextLine = reader.readNext()) != null) {

				//taggedTextFilename="ACL txt/headerandReferences_ACK/"+nextLine[0]+".pdf.txt";
				//taggedTextFilename="citation paper/Paper_text_synopsis_merged/"+nextLine[0]+".txt";
				
				
				
				String abs=nextLine[1];
				
				//for(String f: TaggedTextFiles){
					//System.out.println("f:"+ f);
				String readerfile="citation paper/Paper_text_synopsis_merged/"+nextLine[0]+".txt";
					//String f= nextLine[0]+".txt";
					//fnew = f.substring(f.indexOf("ged/")+4,f.indexOf(".txt")+4).trim();
					File file= new File(readerfile);
					//System.out.println("fnew:"+fnew);
					//fnew= fnew.substring(1,fnew.indexOf("_")).trim();
					//System.out.println("fnew:"+fnew);
					//String readerfile="citation paper/Paper_text_synopsis_merged/"+nextLine[0]+".txt";
					System.out.println(readerfile);
					writefile="citation paper/Paper_text_synopsis_merged_abstractmerged/"+nextLine[0]+".txt";
					System.out.println(writefile);
			    br=new BufferedReader(new FileReader(new File(readerfile)));
			    System.out.println(writefile);
				bw=new BufferedWriter(new FileWriter(writefile,true));
				System.out.println(writefile);
				String file1Str = FileUtils.readFileToString(file);
				System.out.println(file1Str);
				bw.write(file1Str +"..."+ abs);
				//}
				bw.flush();
				bw.close();
			}

			br.close();
			//System.out.println("Done");


		}catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		}



		
}




