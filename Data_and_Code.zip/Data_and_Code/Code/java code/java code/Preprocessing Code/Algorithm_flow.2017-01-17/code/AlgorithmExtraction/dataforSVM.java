

package AlgorithmExtraction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import Util.Directory;
import Util.Util;

public class dataforSVM {
	public static String taggedTextFilename="";
	public static String pdfFilename="";
	@SuppressWarnings("resource")
	public static void main(String args[]) throws IOException{
	


	Writer writer2 = null;
	int iteration=1;
	//Vector<String> TaggedTextFiles = Directory.listAllFiles("pseudocode_and_sbs/Processed final 258", ".tagged.txt", 1);
	
	String file=null;
	String linetest=null;
	CSVWriter writer = new CSVWriter(new FileWriter(("Dat.csv")));
	try {
		//updated Synopsis
		//writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Top20matchedwithCaption.csv"), "UTF-8"));
		System.out.println("In Try");
		
		List<String[]> data = new ArrayList<String[]>();
		String line=null,label=null;
		data.add(new String[] {"text", "label"});
		BufferedReader br = new BufferedReader(new FileReader(new File("./positive_dataset.txt")));
		for(String line_test; (line_test = br.readLine()) != null; ){
			System.out.println("line from testing file " + line_test );
		
				line = line_test.substring(0,line_test.length()-2).trim();
				line=line.replaceAll("\\W+", " ");
				line=line.replaceAll("\\P{L}", " ");
				line=line.toLowerCase();
				label = line_test.substring(line_test.length()-1,line_test.length()).trim();
				System.out.println("File name: "+ line + " : "+label );
				
				//file="pseudocode_and_sbs/Synopsis 258(311) RAKE and BM_input/"+fnew;
				
					//System.out.println("line from testing file " + line_test );
					//BufferedReader br1 = new BufferedReader(new FileReader(new File()));
					//PrintWriter bw1 = new PrintWriter(new BufferedWriter(new FileWriter(file,true)));
					
					//for(String line; (line = br1.readLine()) != null; ) {
						
						//data.add(new String[] {fnew, line});
						//if(line.contains(line_test)|| line_test.contains(line)){
							//bw1.write(line+" ");
							//System.out.println("Matched ::line1 :"+line +" line 2:"+ line_test);
							//System.out.println("**************************************************");
							data.add(new String[] {line,label});
						//}
						//bw1.write(line+" ");
						//writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(""), "UTF-8"));
					}
					
				//}
				
				//bw1.flush();
				//bw1.close();
				//br1.close();
				
			
			writer.writeAll(data);
			System.out.println("done");
			writer.flush();
			writer.close();
			
		}
	
   catch(FileNotFoundException e) {
		//e.printStackTrace();

	} 



	

}
}
