# -*- coding: utf-8 -*-
"""
Created on Fri Aug  4 17:41:36 2017

@author: iqra
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 14:03:32 2016

@author: anam
"""
import numpy
from scipy import interp
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import svm
from sklearn.metrics import auc
from sklearn.cross_validation import StratifiedKFold
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier

###############################################################################


# import some data to play with
mydata = pd.read_csv("vector_processed.csv")
y = mydata["Class"]  #provided your csv has header row, and the label column is named "Label"
n_points=len(mydata)
##select all but the last column as data
X = mydata.ix[:,:-1]
X=X.iloc[:,0:536]
# =============================================================================
# Ql=X.iloc[:, 0:524 ]
# Ct=X.iloc[:, 525:533 ]
# Qt=X.iloc[:, 534:536 ]
# 
# =============================================================================
print(Qt)
#X2
#522
#536
#525:533
#534:536

##################################


cv = StratifiedKFold(y, n_folds=5)

y_real = []
y_proba = []

y_real2 = []
y_proba2 = []
y_real4 = []
y_proba4 = []

#######################################################

classifier2= RandomForestClassifier(class_weight='balanced',criterion='entropy')
for i, (train, test) in enumerate(cv):
    x_train2=X[train[0]:train[len(train)-1]]
    x_test2=X[test[0]:test[len(test)-1]]
    y_train2= y[train[0]:train[len(train)-1]]
    y_test2=y[test[0]:test[len(test)-1]]

    probas_ = classifier2.fit(x_train2, y_train2).predict_proba( x_test2)
    precision, recall, thresholds = precision_recall_curve(y_test2, probas_[:, 1])
   # lab = 'Fold %d AUC=%.4f' % (i+1, auc(recall, precision))
   # plt.plot(recall, precision, lw=1,label=lab)

    y_real2.append(y_test2)
    y_proba2.append(probas_[:, 1])
    
y_real2 = numpy.concatenate(y_real2)
y_proba2 = numpy.concatenate(y_proba2)
precision, recall, _ = precision_recall_curve(y_real2, y_proba2)
lab = 'RF Mean AUC=%.2f' % (auc(recall, precision))
plt.plot(recall, precision, label=lab, lw=2) 
#################################################################

#classifier2= RandomForestClassifier(criterion='entropy')
#classifier= RandomForestClassifier(criterion='entropy')
classifier2 = DecisionTreeClassifier(criterion = "gini", random_state = 100,
                               max_depth=3, min_samples_leaf=5)

for i, (train, test) in enumerate(cv):
    x_train=X[train[0]:train[len(train)-1]]
    x_test=X[test[0]:test[len(test)-1]]
    y_train= y[train[0]:train[len(train)-1]]
    y_test=y[test[0]:test[len(test)-1]]
    
    probas_ = classifier2.fit(x_train, y_train).predict_proba( x_test)
    precision, recall, thresholds = precision_recall_curve(y_test, probas_[:, 1])
    #lab = 'Fold %d AUC=%.4f' % (i+1, auc(recall, precision))
   # plt.plot(recall, precision, lw=1)

    y_real.append(y_test)
    y_proba.append(probas_[:, 1])
    
y_real = numpy.concatenate(y_real)
y_proba = numpy.concatenate(y_proba)
precision, recall, _ = precision_recall_curve(y_real, y_proba)
lab = 'DT Mean AUC=%.2f' % (auc(recall, precision))
plt.plot(recall, precision, label=lab, lw=2 ) 

classifier2 = svm.SVC(kernel='rbf',gamma=0.0001, C=1000, probability=True, class_weight ='balanced')

for i, (train, test) in enumerate(cv):
    x_train=X[train[0]:train[len(train)-1]]
    x_test=X[test[0]:test[len(test)-1]]
    y_train= y[train[0]:train[len(train)-1]]
    y_test=y[test[0]:test[len(test)-1]]
    
    probas_ = classifier2.fit(x_train, y_train).predict_proba( x_test)
    precision, recall, thresholds = precision_recall_curve(y_test, probas_[:, 1])
    #lab = 'Fold %d AUC=%.4f' % (i+1, auc(recall, precision))
   # plt.plot(recall, precision, lw=1)

    y_real4.append(y_test)
    y_proba4.append(probas_[:, 1])
    
y_real4 = numpy.concatenate(y_real4)
y_proba4 = numpy.concatenate(y_proba4)
precision, recall, _ = precision_recall_curve(y_real4, y_proba4)
lab = 'SVM Mean AUC=%.2f' % (auc(recall, precision))
plt.plot(recall, precision, label=lab, lw=2 ) 


plt.xlim([0.02, 1.00])
plt.ylim([0, 1.05])
plt.grid(True)
plt.xlabel('Recall')
plt.ylabel('Precision')
#plt.title('Mean Precision Recall curve, RF, DT and SVM')
plt.rcParams['axes.facecolor']='white'
plt.legend(loc="lower right")
plt.savefig('Mean_PR.png')
plt.show()
#xes[1].step(recall, precision, label=lab, lw=2, color='black')
#axes[1].set_xlabel('Recall')
#axes[1].set_ylabel('Precision')
#axes[1].legend(loc='lower left', fontsize='small')

    
    
    